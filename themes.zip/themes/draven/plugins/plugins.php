<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

add_action( 'tgmpa_register', 'draven_register_required_plugins' );

if(!function_exists('draven_register_required_plugins')){

	function draven_register_required_plugins() {

	    $initial_required = array(
	        'lastudio' => array(
	            'source'    => 'https://la-studioweb.com/file-resouces/draven/plugins/lastudio/2.0.4/lastudio.zip',
                'version'   => '2.0.4'
            ),
            'lastudio-elements' => array(
	            'source'    => 'https://la-studioweb.com/file-resouces/draven/plugins/lastudio-elements/1.0.2.7/lastudio-elements.zip',
                'version'   => '1.0.2.7'
            ),
            'lastudio-header-footer-builders' => array(
	            'source'    => 'https://la-studioweb.com/file-resouces/draven/plugins/lastudio-header-footer-builders/1.0.2.3/lastudio-header-footer-builders.zip',
                'version'   => '1.0.2.3'
            ),
            /*'revslider' => array(
	            'source'    => 'https://la-studioweb.com/file-resouces/shared/plugins/revslider/6.0.5/revslider.zip',
                'version'   => '6.0.5'
            ),*/
            'draven-demo-data' => array(
                'source'    => 'https://la-studioweb.com/file-resouces/draven/plugins/draven-demo-data/1.0.3/draven-demo-data.zip',
                'version'   => '1.0.3'
            )
        );

	    $from_option = get_option('draven_required_plugins_list', $initial_required);

		$plugins = array();

		$plugins['lastudio'] = array(
			'name'					=> esc_html_x('LA-Studio Core', 'admin-view', 'draven'),
			'slug'					=> 'lastudio',
			'source'				=> isset($from_option['lastudio'], $from_option['lastudio']['source']) ? $from_option['lastudio']['source'] : $initial_required['lastudio']['source'],
			'required'				=> true,
			'version'				=> isset($from_option['lastudio'], $from_option['lastudio']['version']) ? $from_option['lastudio']['version'] : $initial_required['lastudio']['version']
		);

		$plugins['lastudio-header-footer-builders'] = array(
			'name'					=> esc_html_x('LA-Studio Header Builder', 'admin-view', 'draven'),
			'slug'					=> 'lastudio-header-footer-builders',
			'source'				=> isset($from_option['lastudio-header-footer-builders'], $from_option['lastudio-header-footer-builders']['source']) ? $from_option['lastudio-header-footer-builders']['source'] : $initial_required['lastudio-header-footer-builders']['source'],
			'required'				=> true,
			'version'				=> isset($from_option['lastudio-header-footer-builders'], $from_option['lastudio-header-footer-builders']['version']) ? $from_option['lastudio-header-footer-builders']['version'] : $initial_required['lastudio-header-footer-builders']['version']
		);


        $plugins['elementor'] = array(
            'name' 					=> esc_html_x('Elementor Page Builder', 'admin-view', 'draven'),
            'slug' 					=> 'elementor',
            'required' 				=> true,
            'version'				=> '2.6.2'
        );

		$plugins['lastudio-elements'] = array(
			'name'					=> esc_html_x('LaStudio Elements For Elementor', 'admin-view', 'draven'),
			'slug'					=> 'lastudio-elements',
			'source'				=> isset($from_option['lastudio-elements'], $from_option['lastudio-elements']['source']) ? $from_option['lastudio-elements']['source'] : $initial_required['lastudio-elements']['source'],
			'required'				=> true,
			'version'				=> isset($from_option['lastudio-elements'], $from_option['lastudio-elements']['version']) ? $from_option['lastudio-elements']['version'] : $initial_required['lastudio-elements']['version']
		);

		/* $plugins['woocommerce'] = array(
			'name'     				=> esc_html_x('WooCommerce', 'admin-view', 'draven'),
			'slug'     				=> 'woocommerce',
			'version'				=> '3.6.5',
			'required' 				=> false
		); */

        $plugins['draven-demo-data'] = array(
            'name'					=> esc_html_x('Draven Package Demo Data', 'admin-view', 'draven'),
            'slug'					=> 'draven-demo-data',
            'source'				=> isset($from_option['draven-demo-data'], $from_option['draven-demo-data']['source']) ? $from_option['draven-demo-data']['source'] : $initial_required['draven-demo-data']['source'],
            'required'				=> false,
            'version'				=> isset($from_option['draven-demo-data'], $from_option['draven-demo-data']['version']) ? $from_option['draven-demo-data']['version'] : $initial_required['draven-demo-data']['version']
        );

	/*	$plugins['envato-market'] = array(
			'name'     				=> esc_html_x('Envato Market', 'admin-view', 'draven'),
			'slug'     				=> 'envato-market',
			'source'   				=> 'https://envato.github.io/wp-envato-market/dist/envato-market.zip',
			'required' 				=> false,
			'version' 				=> '2.0.1'
		); */

		$plugins['contact-form-7'] = array(
			'name' 					=> esc_html_x('Contact Form 7', 'admin-view', 'draven'),
			'slug' 					=> 'contact-form-7',
			'required' 				=> false
		);

		/* $plugins['revslider'] = array(
			'name'					=> esc_html_x('Slider Revolution', 'admin-view', 'draven'),
			'slug'					=> 'revslider',
			'source'				=> isset($from_option['revslider'], $from_option['revslider']['source']) ? $from_option['revslider']['source'] : $initial_required['revslider']['source'],
			'required'				=> false,
			'version'				=> isset($from_option['revslider'], $from_option['revslider']['version']) ? $from_option['revslider']['version'] : $initial_required['revslider']['version']
		);*/

		$config = array(
			'id'           				=> 'draven',
			'default_path' 				=> '',
			'menu'         				=> 'tgmpa-install-plugins',
			'has_notices'  				=> true,
			'dismissable'  				=> true,
			'dismiss_msg'  				=> '',
			'is_automatic' 				=> false,
			'message'      				=> ''
		);

		tgmpa( $plugins, $config );

	}

}